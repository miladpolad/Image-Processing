# gesture-range-control

**Python packages required:**
* cvzone 1.5.0
* mediapipe 0.8.7.1
* pyfirmata 1.1.0

**Arduino Configuration**
- Open IDE Arduino
- Select File -> Example -> Firmata -> StandardFirmata
- Select Tools -> Board -> Arduino/Genuino Uno
- Select Tools -> Port -> *choose your port COM*
- Upload

